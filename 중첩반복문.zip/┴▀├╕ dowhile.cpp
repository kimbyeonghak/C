#include<stdio.h>

int main(){
	
	int i=1;
	
	do{
		printf("%d�г� ",i);
		i++;
		
		int j=7;
		do{
			printf("%d�� ",j);
			j--;
			
		}while(j>0);
		printf("\n");
	}while(i<8);
	
		
} 
