#include<stdio.h>

int main(){
	
	for(int i=5;i>0;i--){
		
		for(int j=i;j>0;j--){
			
			printf("%2d",j);
		}
		printf("\n");
	}
}
