#include<stdio.h>

int main(){
	
	
	for(int i=1;i<7;i++){
		printf(" %d�г�",i);
		
		for(int j=1;j<8;j++){
			printf(" %d��",j);
		}
		printf("\n");
	}
}
