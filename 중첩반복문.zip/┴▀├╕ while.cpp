#include<stdio.h>

int main(){
	
	int i=6;
	while(i>0){
		
		printf("%d�г� ",i);
		
		int j=1;
		while(j<8){
			printf("%d�� ",j);
			j++;
		}
		printf("\n");
		i--;
	}
}
